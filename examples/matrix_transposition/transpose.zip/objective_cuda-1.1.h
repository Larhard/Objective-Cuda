#include <cassert>
#include <cstdarg>
#include <cstdio>
#include <cstring>
#include <exception>

#include "cuda.h"

namespace CuError {
    struct CuException : public std::exception {
        char *msg;
        mutable char *return_msg;

        CuException() {
            msg = new char[1];
            msg[0] = 0;
            return_msg = NULL;
        }

        CuException(const char* format, ...) {
            char buffer[1024];
            va_list args;
            va_start (args, format);
            vsprintf (buffer, format, args);
            perror (buffer);
            va_end (args);

            msg = new char[strlen(buffer) + 1];
            strcpy(msg, buffer);
            return_msg = NULL;
        }

        ~CuException() throw() {
            if (return_msg) {
                delete [] return_msg;
            }
            if (msg) {
                delete [] msg;
            }
        }

        virtual const char* default_message() const throw() {
            return "Something gone wrong\n";
        }

        virtual const char* what() const throw () {
            if (! return_msg) {
                return_msg = new char[strlen(msg), strlen(default_message()) + 1];
                strcpy(return_msg, default_message());
                strcat(return_msg, msg);
            }
            return return_msg;
        }
    };

    #define CU_EXCEPTION(name,def_msg) \
            struct name : public CuException { \
                name () {} name (const char *format, ...) { \
                    char buffer[1024]; \
                    va_list args; \
                    va_start (args, format); \
                    vsprintf (buffer, format, args); \
                    perror (buffer); \
                    va_end (args); \
                    msg = new char[strlen(buffer) + 1]; \
                    strcpy(msg, buffer); \
                    return_msg = NULL; \
                } \
                virtual const char* default_message() const throw() { return def_msg; } \
            };

        CU_EXCEPTION(DeviceNotExist, "Device does not exist\n");
        CU_EXCEPTION(ContextCreateError, "Context could not be created\n");
        CU_EXCEPTION(ModuleLoadError, "Module could not be loaded\n");
        CU_EXCEPTION(DefaultModuleNotExist, "Default kernel is no set\n");
        CU_EXCEPTION(KernelGetError, "Kernel could not be acquired\n");
        CU_EXCEPTION(KernelLaunchError, "Kernel could not be launched\n");
        CU_EXCEPTION(ContextSynchronizeError, "Context synchronization failed\n");

    #undef CU_EXCEPTION

    const char *strerror(CUresult result) 
    { 
        switch(result) { 
            case CUDA_SUCCESS: return "No errors"; 
            case CUDA_ERROR_INVALID_VALUE: return "Invalid value"; 
            case CUDA_ERROR_OUT_OF_MEMORY: return "Out of memory"; 
            case CUDA_ERROR_NOT_INITIALIZED: return "Driver not initialized"; 
            case CUDA_ERROR_DEINITIALIZED: return "Driver deinitialized"; 

            case CUDA_ERROR_NO_DEVICE: return "No CUDA-capable device available"; 
            case CUDA_ERROR_INVALID_DEVICE: return "Invalid device"; 

            case CUDA_ERROR_INVALID_IMAGE: return "Invalid kernel image"; 
            case CUDA_ERROR_INVALID_CONTEXT: return "Invalid context"; 
            case CUDA_ERROR_CONTEXT_ALREADY_CURRENT: return "Context already current"; 
            case CUDA_ERROR_MAP_FAILED: return "Map failed"; 
            case CUDA_ERROR_UNMAP_FAILED: return "Unmap failed"; 
            case CUDA_ERROR_ARRAY_IS_MAPPED: return "Array is mapped"; 
            case CUDA_ERROR_ALREADY_MAPPED: return "Already mapped"; 
            case CUDA_ERROR_NO_BINARY_FOR_GPU: return "No binary for GPU"; 
            case CUDA_ERROR_ALREADY_ACQUIRED: return "Already acquired"; 
            case CUDA_ERROR_NOT_MAPPED: return "Not mapped"; 
            case CUDA_ERROR_NOT_MAPPED_AS_ARRAY: return "Mapped resource not available for access as an array"; 
            case CUDA_ERROR_NOT_MAPPED_AS_POINTER: return "Mapped resource not available for access as a pointer"; 
            case CUDA_ERROR_ECC_UNCORRECTABLE: return "Uncorrectable ECC error detected"; 
            case CUDA_ERROR_UNSUPPORTED_LIMIT: return "CUlimit not supported by device";    

            case CUDA_ERROR_INVALID_SOURCE: return "Invalid source"; 
            case CUDA_ERROR_FILE_NOT_FOUND: return "File not found"; 
            case CUDA_ERROR_SHARED_OBJECT_SYMBOL_NOT_FOUND: return "Link to a shared object failed to resolve"; 
            case CUDA_ERROR_SHARED_OBJECT_INIT_FAILED: return "Shared object initialization failed"; 

            case CUDA_ERROR_INVALID_HANDLE: return "Invalid handle"; 

            case CUDA_ERROR_NOT_FOUND: return "Not found"; 

            case CUDA_ERROR_NOT_READY: return "CUDA not ready"; 

            case CUDA_ERROR_LAUNCH_FAILED: return "Launch failed"; 
            case CUDA_ERROR_LAUNCH_OUT_OF_RESOURCES: return "Launch exceeded resources"; 
            case CUDA_ERROR_LAUNCH_TIMEOUT: return "Launch exceeded timeout"; 
            case CUDA_ERROR_LAUNCH_INCOMPATIBLE_TEXTURING: return "Launch with incompatible texturing"; 

            case CUDA_ERROR_UNKNOWN: return "Unknown error"; 

            default: return "Unknown CUDA error value"; 
        } 
    }

}

class Cuda{
    private:
        CUdevice cuDevice;
        CUmodule default_module;
        CUcontext cuContext;

    public:
        Cuda(int device_id=0, int init_flags=0) {
            // Init driver
            cuInit(init_flags);

            // Get device handler
            CUresult res = cuDeviceGet(&cuDevice, device_id);
            if (res != CUDA_SUCCESS) {
                throw CuError::DeviceNotExist("Device id: %d\n%s", device_id, CuError::strerror(res));
            }

            // Create context
            res = cuCtxCreate(&cuContext, 0, cuDevice);
            if (res != CUDA_SUCCESS) {
                throw CuError::ContextCreateError("%s", CuError::strerror(res));
            }
        }

        ~Cuda() {
            cuCtxDestroy(cuContext);
        }

        CUmodule set_default_module(CUmodule module) {
            // Set default module from existing module
            default_module = module;
            return module;
        }

        CUmodule set_default_module(const char *module_name) {
            // Set default module from path
            return set_default_module(create_module(module_name));
        }

        CUmodule create_module(const char *module_name) {
            // Create module from .ptx
            CUmodule cuModule = (CUmodule)0;
            CUresult res = cuModuleLoad(&cuModule, module_name);
            if (res != CUDA_SUCCESS) {
                throw CuError::ModuleLoadError("Module id: %d\n%s", res, CuError::strerror(res));
            }
            return cuModule;
        }

        CUfunction get_kernel(const char *kernel_name) {
            if (default_module) {
                return get_kernel(kernel_name, default_module);
            } else {
                throw CuError::DefaultModuleNotExist();
            }
        }

        CUfunction get_kernel(const char *kernel_name, CUmodule cuModule) {
            // Get kernel handler from module
            CUfunction kernel;
            CUresult res = cuModuleGetFunction(&kernel, cuModule, kernel_name);
            if (res != CUDA_SUCCESS) {
                throw CuError::KernelGetError("Kernel name: %s\n%s", kernel_name, CuError::strerror(res));
            }
            return kernel;
        }

        void launch_kernel_3d(CUfunction kernel,
                uint grid_dim_x, uint grid_dim_y, uint grid_dim_z,
                uint block_dim_x, uint block_dim_y, uint block_dim_z,
                void ** args = NULL,
                uint shared_mem_bytes = 0,
                CUstream h_stream = 0,
                void ** extra = NULL) {

            assert(grid_dim_x > 0);
            assert(grid_dim_y > 0);
            assert(grid_dim_z > 0);
            assert(block_dim_x > 0);
            assert(block_dim_y > 0);
            assert(block_dim_z > 0);
            
            if (args == NULL) {
                args = new void *[0];
            }

            CUresult res = cuLaunchKernel(kernel,
                    grid_dim_x, grid_dim_y, grid_dim_z,
                    block_dim_x, block_dim_y, block_dim_z,
                    shared_mem_bytes,
                    h_stream,
                    args,
                    extra);
            if (res != CUDA_SUCCESS){
                throw CuError::KernelLaunchError("%s", CuError::strerror(res));
            }
        }
        void launch_kernel(CUfunction kernel,
                uint grid_dim_x,
                uint block_dim_x,
                void ** args = NULL,
                uint shared_mem_bytes = 0,
                CUstream h_stream = 0,
                void ** extra = NULL) {
            launch_kernel_3d(kernel,
                    grid_dim_x, 1, 1,
                    block_dim_x, 1, 1,
                    args,
                    shared_mem_bytes,
                    h_stream,
                    extra);
        }
        void launch_kernel_2d(CUfunction kernel,
                uint grid_dim_x, uint grid_dim_y,
                uint block_dim_x, uint block_dim_y,
                void ** args = NULL,
                uint shared_mem_bytes = 0,
                CUstream h_stream = 0,
                void ** extra = NULL) {
            launch_kernel_3d(kernel,
                    grid_dim_x, grid_dim_y, 1,
                    block_dim_x, block_dim_y, 1,
                    args,
                    shared_mem_bytes,
                    h_stream,
                    extra);
        }

        void ctx_synchronize() {
            CUresult res = cuCtxSynchronize();
            if (res != CUDA_SUCCESS) {
                throw CuError::ContextSynchronizeError("%s", CuError::strerror(res));
            }
        }
};
